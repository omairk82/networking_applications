/*
** auctionserver.c --
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

string regArr[15][3]; //registration list

struct Seller //struct for seller information
{
	int num; //seller number
	int type;
	string name;
	string password;
	int bankacct;
	bool valid;
	string ipaddr;
	int socketnum;
	string itemlist[15]; //assumed max item for sale by any user = 15
};

struct Bidder //struct for bidder information
{
	int num; //bidder number
	int type;
	string name;
	string password;
	int bankacct;
	bool valid;
	string ipaddr;
	int socketnum;
};

Seller * sptr = new Seller[2]; //assuming no more than 2 sellers
Bidder * bptr = new Bidder[2]; //asuuming no more than 2 bidders
int sptr_cntr = -1; //cntr for how many Seller were created
int bptr_cntr = -1; //cntr for how many Bidder were created
int svalid = -1; //tracks number of valid seller logins
int sil_cntr = -1; //cntr for how many Sellers uploaded item lists

#define TCP_PORT_AS1 "1100996"  // Auction Server TCP port for phase 1
#define TCP_PORT_AS2 "1200996" // Auction Server TCP port for phase 2
#define TCP_PORT_S1 "2200996" // Seller 1 Server TCP port for phase 3
#define TCP_PORT_S2 "2100996" // Seller 2 Server TCP port for phase 3
#define TCP_PORT_B1 "4100996" // Bidder 1 Server UDP port for phase 3
#define TCP_PORT_B2 "4200996" // Bidder 2 Server UDP port for phase 3
#define UDP_PORT_B1 "3100996" // Bidder 1 Server UDP port for phase 3
#define UDP_PORT_B2 "3200996" // Bidder 2 Server UDP port for phase 3

int readFile(const char* filenm) {
	ifstream file(filenm);
	string str;
	int row = 0;
	while (getline(file, str))
	{
		//cout << str <<endl;
		// Process str
		int i =0;
		stringstream ssin(str);
		while (ssin.good() && i < 3){
			ssin >> regArr[row][i];
			++i;
		}
		row++;
	}
	return row;
}

int get_port_num(int sockfd) {
	struct sockaddr_in sin;
	socklen_t len = sizeof(sin);
	if (getsockname(sockfd, (struct sockaddr *)&sin, &len) == -1)
		perror("getsockname");
//	else
//    	printf("port number %d\n", ntohs(sin.sin_port));

	return ntohs(sin.sin_port);
}

string getIPfromSocket(int s) {
	// assume s is a connected socket
	socklen_t len;
	struct sockaddr_storage addr;
	char ipstr[INET6_ADDRSTRLEN];
	int port;
	len = sizeof addr;
	getpeername(s, (struct sockaddr*)&addr, &len);
	// deal with both IPv4 and IPv6:
	if (addr.ss_family == AF_INET) {
	struct sockaddr_in *s = (struct sockaddr_in *)&addr;
	port = ntohs(s->sin_port);
	inet_ntop(AF_INET, &s->sin_addr, ipstr, sizeof ipstr);
	} else { // AF_INET6
	struct sockaddr_in6 *s = (struct sockaddr_in6 *)&addr;
	port = ntohs(s->sin6_port);
	inet_ntop(AF_INET6, &s->sin6_addr, ipstr, sizeof ipstr);
	}
//	printf("Peer IP address: %s\n", ipstr);
//	printf("Peer port : %d\n", port);
	return ipstr;
}

string checkLoginBidder (Bidder *bptr, int cntr) {
	string out = "Rejected";
	for (int i =0; i<15; i++) {
		if (strcmp(regArr[i][0].c_str(),(bptr[cntr].name).c_str())==0) { //check for matching usernames
			if (strcmp(regArr[i][1].c_str(),(bptr[cntr].password).c_str())==0) { //check for matching passwords
				if (atoi((regArr[i][2]).c_str())==bptr[cntr].bankacct) { //check for matching bankacct
					out = "Accepted";
					break;
				}
			}
		}
	}
	return out;
}

string checkLoginSeller (Seller *sptr, int cntr) {
	string out = "Rejected";
	for (int i =0; i<15; i++) {
		if (strcmp(regArr[i][0].c_str(),(sptr[cntr].name).c_str())==0) { //check for matching usernames
			if (strcmp(regArr[i][1].c_str(),(sptr[cntr].password).c_str())==0) { //check for matching passwords
				if (atoi((regArr[i][2]).c_str())==sptr[cntr].bankacct) { //check for matching bankacct
					out = "Accepted";
					break;
				}
			}
		}
	}
	return out;
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

void CreateMultiSynchIOServer_Phase1() {
	fd_set master;    // master file descriptor list
	fd_set read_fds;  // temp file descriptor list for select()
	int fdmax;        // maximum file descriptor number

	int listener;     // listening socket descriptor
	int newfd;        // newly accept()ed socket descriptor
	struct sockaddr_storage remoteaddr; // client address
	socklen_t addrlen;

	char buf[256];    // buffer for client data
	int nbytes;

	char s[INET6_ADDRSTRLEN];
	char remoteIP[INET6_ADDRSTRLEN];

	int yes=1;        // for setsockopt() SO_REUSEADDR, below
	int i, j, rv;

	struct addrinfo hints, *ai, *p;

	FD_ZERO(&master);    // clear the master and temp sets
	FD_ZERO(&read_fds);

	// get us a socket and bind it
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo("nunki.usc.edu", TCP_PORT_AS1, &hints, &ai)) != 0) {
			fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
			exit(1);
		}
	
	for(p = ai; p != NULL; p = p->ai_next) {
		listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
		if (listener < 0) { 
			continue;
		}
		
		// lose the pesky "address already in use" error message
		setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

		if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) {
			close(listener);
			continue;
		}

		break;
	}

	// if we got here, it means we didn't get bound
	if (p == NULL) {
		fprintf(stderr, "selectserver: failed to bind\n");
		exit(2);
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr), s, sizeof s); //get server's IP address
	cout << "Phase 1: " << "Auction Server has TCP port number " << get_port_num(listener) << " and IP address: " << s << endl;

	freeaddrinfo(ai); // all done with this

	// listen
	if (listen(listener, 10) == -1) {
		perror("listen");
		exit(3);
	}

	// add the listener to the master set
	FD_SET(listener, &master);

	// keep track of the biggest file descriptor
	fdmax = listener; // so far, it's this one

	// main loop
	for(;;) {
		//Check Phase 1 stop condition - at least 2 bidder and 2 seller logins have been attempted (counting starts at -1)
		if (sptr_cntr >=1 and bptr_cntr >=1) {
			cout << "End of Phase 1 for Auction Server" << endl;
			close(listener);
			break;
		}

		read_fds = master; // copy it
		if (select(fdmax+1, &read_fds, NULL, NULL, NULL) == -1) {
			perror("select");
			exit(4);
		}

		// run through the existing connections looking for data to read
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &read_fds)) { // we got one!!
				if (i == listener) {
					// handle new connections
					addrlen = sizeof remoteaddr;
					newfd = accept(listener,
						(struct sockaddr *)&remoteaddr,
						&addrlen);

					if (newfd == -1) {
						perror("accept");
					} else {
						FD_SET(newfd, &master); // add to master set
						if (newfd > fdmax) {    // keep track of the max
							fdmax = newfd;
						}
//						printf("auction server: new connection from %s on "
//							"socket %d\n",
//							inet_ntop(remoteaddr.ss_family,
//								get_in_addr((struct sockaddr*)&remoteaddr),
//								remoteIP, INET6_ADDRSTRLEN),
//							newfd);
					}
				} else {
					// handle data from a client
					if ((nbytes = recv(i, buf, sizeof buf, 0)) <= 0) {
						// got error or connection closed by client
						if (nbytes == 0) {
							// connection closed
//							printf("auction server: socket %d hung up\n", i);
						} else {
							perror("recv");
						}
						close(i); // bye!
						FD_CLR(i, &master); // remove from master set
					} else {

						// we got some data from a client
						//echo data from client
						buf[nbytes] = '\0';
						//printf("auction server: received '%s'\n",buf);

						//process user login info
						int logintype =0; //variable for type of person logging in
						istringstream oss(buf);
						string word;
						int cntr;
						while(getline(oss, word, '#')) { //cmd word processing
							if (strcmp(word.c_str(),"Login")==0) {
								cntr=0; //reset data ref cntr
								while(oss >> word) {//cmd argument processing
									if (strcmp(word.c_str(),"1")==0) { //store bidder entries
										logintype = 1; //set login type
										bptr_cntr++; //inc Bidder cntr
										bptr[bptr_cntr].type = atoi(word.c_str()); //store type info
										cntr++;
										while(oss >> word) { //bidder argument processing
											//cout << "[" << word << "] "<< endl;
											if (cntr==1) {bptr[bptr_cntr].name = word;} //store name
											else if (cntr==2) {bptr[bptr_cntr].password = word;} //store password
											else if (cntr==3) {bptr[bptr_cntr].bankacct = atoi(word.c_str());} //store bank acct
											cntr++; //increase data ref cntr
										}
										//store network info from users
										bptr[bptr_cntr].num = bptr_cntr+1; //store bidder number
										bptr[bptr_cntr].ipaddr = getIPfromSocket(i); //store bidder phase 1 IP addr
										bptr[bptr_cntr].socketnum = get_port_num(i); //store bidder phase 1 port number
									}
									else if (strcmp(word.c_str(),"2")==0) { //store seller entries
										logintype = 2; //set login type
										sptr_cntr++; //inc Seller cntr
										sptr[sptr_cntr].type = atoi(word.c_str()); //store type info
										cntr++;
										while(oss >> word) { //bidder argument processing
											//cout << "[" << word << "] "<< endl;
											if (cntr==1) {sptr[sptr_cntr].name = word;} //store name
											else if (cntr==2) {sptr[sptr_cntr].password = word;} //store password
											else if (cntr==3) {sptr[sptr_cntr].bankacct = atoi(word.c_str());} //store bank acct
											cntr++;
										}
										//store network info from users
										sptr[sptr_cntr].num = sptr_cntr+1; //store seller number
										sptr[sptr_cntr].ipaddr = getIPfromSocket(i); //store seller phase 1 IP addr
										sptr[sptr_cntr].socketnum = get_port_num(i); //store seller phase 1 port number
									}
									break;
								}
							}
							else {break;}
						}
						//process validity of login
						if (logintype==1) { //Bidder login
							string valid = checkLoginBidder(bptr, bptr_cntr);
							if (strcmp(valid.c_str(),"Accepted")==0) {bptr[bptr_cntr].valid = true;}
							else {bptr[bptr_cntr].valid = false;}
							cout << "Phase 1: Authentication Request. User#: Bidder#" << (bptr_cntr+1) <<
									" UserName " << bptr[bptr_cntr].name <<
									 " Password: " << bptr[bptr_cntr].password <<
									 " Bank Account: " << bptr[bptr_cntr].bankacct <<
									 " User IP Addr: " << getIPfromSocket(i) <<
									 ". Authorized: " << valid << endl;

							//send login reply message
							char rplymsg[75];
							if (bptr[bptr_cntr].valid == true) {
								strcpy(rplymsg, "Accepted#");
								strcat(rplymsg, s);
								strcat(rplymsg, " ");
								strcat(rplymsg, TCP_PORT_AS2); //static port number for phase 2
								if (send(i, rplymsg, strlen(rplymsg), 0) == -1) {perror("send");}
							}
							else {
								char rplymsg[] = "Rejected#";
								if (send(i, rplymsg, strlen(rplymsg), 0) == -1) {perror("send");}
							}
						}
						else if (logintype==2) { //Seller login
							string valid = checkLoginSeller(sptr, sptr_cntr);
							if (strcmp(valid.c_str(),"Accepted")==0) {sptr[sptr_cntr].valid = true;}
							else {sptr[sptr_cntr].valid = false;}
							cout << "Phase 1: Authentication Request. User#: Seller#" << (sptr_cntr+1) <<
									" UserName " << sptr[sptr_cntr].name <<
									 " Password: " << sptr[sptr_cntr].password <<
									 " Bank Account: " << sptr[sptr_cntr].bankacct <<
									 " User IP Addr: " << getIPfromSocket(i) <<
									 ". Authorized: " << valid << endl;
							//send login reply message
							if (sptr[sptr_cntr].valid == true) {
								svalid++; //increment # of valid seller logins
								if (sptr[sptr_cntr].valid == true) {
									cout << "Phase 1: Auction Server IP Address: " << s
											<< " PreAuction Port Number: " << TCP_PORT_AS2
											<< " sent to the Seller# " << (sptr_cntr+1) << endl;
								}
								char rplymsg[75];
								strcpy(rplymsg, "Accepted#");
								strcat(rplymsg, s);
								strcat(rplymsg, " ");
								strcat(rplymsg, TCP_PORT_AS2); //static port number for phase 2
								if (send(i, rplymsg, strlen(rplymsg), 0) == -1) {perror("send");}
							}
							else {
								char rplymsg[] = "Rejected#";
								if (send(i, rplymsg, strlen(rplymsg), 0) == -1) {perror("send");}
							}
						}
					}
				} // END handle data from client
			} // END got new incoming connection
		} // END looping through file descriptors
	} // END for(;;)--and you thought it would never end!
}

void CreateMultiSynchIOServer_Phase2() {
	fd_set master;    // master file descriptor list
	fd_set read_fds;  // temp file descriptor list for select()
	int fdmax;        // maximum file descriptor number

	int listener;     // listening socket descriptor
	int newfd;        // newly accept()ed socket descriptor
	struct sockaddr_storage remoteaddr; // client address
	socklen_t addrlen;

	char buf[256];    // buffer for client data
	int nbytes;

	char s[INET6_ADDRSTRLEN];
	char remoteIP[INET6_ADDRSTRLEN];

	int yes=1;        // for setsockopt() SO_REUSEADDR, below
	int i, j, rv;

	struct addrinfo hints, *ai, *p;

	FD_ZERO(&master);    // clear the master and temp sets
	FD_ZERO(&read_fds);

	// get us a socket and bind it
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo("nunki.usc.edu", TCP_PORT_AS2, &hints, &ai)) != 0) {
			fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
			exit(1);
		}

	for(p = ai; p != NULL; p = p->ai_next) {
		listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
		if (listener < 0) {
			continue;
		}

		// lose the pesky "address already in use" error message
		setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

		if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) {
			close(listener);
			continue;
		}

		break;
	}

	// if we got here, it means we didn't get bound
	if (p == NULL) {
		fprintf(stderr, "selectserver: failed to bind\n");
		exit(2);
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr), s, sizeof s); //get server's IP address
	cout << "Phase 2: " << "Auction Server has IP address: " << s << " PreAuction TCP port number " <<
			get_port_num(listener) <<  endl;

	freeaddrinfo(ai); // all done with this

	// listen
	if (listen(listener, 10) == -1) {
		perror("listen");
		exit(3);
	}

	// add the listener to the master set
	FD_SET(listener, &master);

	// keep track of the biggest file descriptor
	fdmax = listener; // so far, it's this one

	// main loop
	for(;;) {
		//Check Phase 2 stop condition - same number of item lists uploaded as number of succesful seller logins
		if (sil_cntr >= svalid or svalid==-1) {
			cout << "End of Phase 2 for Auction Server" << endl;
			close(listener);
			break;
		}

		read_fds = master; // copy it
		if (select(fdmax+1, &read_fds, NULL, NULL, NULL) == -1) {
			perror("select");
			exit(4);
		}

		// run through the existing connections looking for data to read
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &read_fds)) { // we got one!!
				if (i == listener) {
					// handle new connections
					addrlen = sizeof remoteaddr;
					newfd = accept(listener,
						(struct sockaddr *)&remoteaddr,
						&addrlen);

					if (newfd == -1) {
						perror("accept");
					} else {
						FD_SET(newfd, &master); // add to master set
						if (newfd > fdmax) {    // keep track of the max
							fdmax = newfd;
						}
//						printf("auction server: new connection from %s on "
//							"socket %d\n",
//							inet_ntop(remoteaddr.ss_family,
//								get_in_addr((struct sockaddr*)&remoteaddr),
//								remoteIP, INET6_ADDRSTRLEN),
//							newfd);
					}
				} else {
					// handle data from a client
					if ((nbytes = recv(i, buf, sizeof buf, 0)) <= 0) {
						// got error or connection closed by client
						if (nbytes == 0) {
							// connection closed
//							printf("auction server: socket %d hung up\n", i);
						} else {
							perror("recv");
						}
						close(i); // bye!
						FD_CLR(i, &master); // remove from master set
					} else {

						// we got some data from a client
						//echo data from client
						buf[nbytes] = '\0';
						//printf("auction server: received '%s'\n",buf);

						//process seller item list info
						istringstream oss(buf);
						string word;
						int cntr;
						while(getline(oss, word, '#')) { //cmd word processing
							//cout<<word<<endl;
							if (strcmp(word.c_str(),"ItemList")==0) {
								while(oss >> word) {//cmd seller name processing
									//cout << "[" << word << "] ";
									for (int j=0; j<2; j++) {
										if (strcmp(word.c_str(), sptr[j].name.c_str())==0) {
											//cmd item processing
											cntr=0; //reset data ref cntr
											while (getline(oss, word, '\n')) {
												//cout << word << endl;
												sptr[j].itemlist[cntr] = word;
												cntr++;
											}
											cout << "Phase 2: Seller #" << sptr[j].num << " sent item lists" << endl;
											cout << "Phase 2: ";
											for (int k=0; k<cntr; k++) {
												cout << sptr[j].itemlist[k] << endl;
											}
											break;
										}
									}
									break; //break the while loop
								}
							}
							else {break;}
						}

						//send reply message
						char rplymsg[] = "Accepted#";
						if (send(i, rplymsg, strlen(rplymsg), 0) == -1) {perror("send");}

						sil_cntr++; //increment the seller item list upload counter
					}
				} // END handle data from client
			} // END got new incoming connection
		} // END looping through file descriptors
	} // END for(;;)--and you thought it would never end!
}

int main(void)
{

	//***** Phase 1 *****

	//load registration list
	const char* regFile = "Registration.txt";
	int row = readFile(regFile);
//	for (int jj=0; jj<row; jj++) {
//		for (int ii=0; ii<3; ii++) {
//			cout << regArr[jj][ii] << endl;
//		}
//	}

	//return 0;

	//cout<<"setting up server!"<<endl;
	CreateMultiSynchIOServer_Phase1();
    
	//***** Phase 2 *****
	CreateMultiSynchIOServer_Phase2();

	//***** Phase 3 *****
	cout << "End of Phase 3 for Auction Server (Did not finish project past Phase 2)" << endl;
	//***** NOTE: The seller code ends here as I did not finish the project beyond phase 2. *****


    return 0;
}

