/*
** seller.c --
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unistd.h>

using namespace std;

int sellerID = 2; //seller id #
string regArr[4]; //registration info array

string ip_ph2;
string pn_ph2 = "0";

#define TCP_PORT_AS1 "1100996"  // Auction Server TCP port for phase 1
#define TCP_PORT_AS2 "1200996" // Auction Server TCP port for phase 2
#define TCP_PORT_S1 "2200996" // Seller 1 Server TCP port for phase 3
#define TCP_PORT_S2 "2100996" // Seller 2 Server TCP port for phase 3
#define TCP_PORT_B1 "4100996" // Bidder 1 Server UDP port for phase 3
#define TCP_PORT_B2 "4200996" // Bidder 2 Server UDP port for phase 3
#define UDP_PORT_B1 "3100996" // Bidder 1 Server UDP port for phase 3
#define UDP_PORT_B2 "3200996" // Bidder 2 Server UDP port for phase 3

#define MAXDATASIZE 100 // max number of bytes we can get at once 

void readFile(char* filenm) {
	ifstream file(filenm);
	string str;
	while (getline(file, str))
	{
		//cout << str <<endl;
		// Process str
		int i =0;
		stringstream ssin(str);
		while (ssin.good() && i < 4){
			ssin >> regArr[i];
			++i;
		}
	}
}

int get_port_num(int sockfd) {
	struct sockaddr_in sin;
	socklen_t len = sizeof(sin);
	if (getsockname(sockfd, (struct sockaddr *)&sin, &len) == -1)
		perror("getsockname");
//	else
//    	printf("port number %d\n", ntohs(sin.sin_port));

	return ntohs(sin.sin_port);
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int create_client_seller_TCP(){
	int sockfd;
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo("nunki.usc.edu", TCP_PORT_AS1, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and connect to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("seller: socket");
			continue;
		}

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("seller: connect");
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "seller: failed to connect\n");
		return 2;
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
			s, sizeof s);

	//printf("bidder: connecting to %s\n", s);
	cout << "Phase 1: " << "Seller " << sellerID << " has TCP port " << get_port_num(sockfd) << " and IP address: " << s << endl;

	freeaddrinfo(servinfo); // all done with this structure

	return sockfd;
}

int create_client_seller_TCP_ph2(){
	int sockfd;
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo("nunki.usc.edu", pn_ph2.c_str(), &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and connect to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("seller: socket");
			continue;
		}

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("seller: connect");
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "seller: failed to connect\n");
		return 2;
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
			s, sizeof s);

	//printf("bidder: connecting to %s\n", s);
	cout << "Phase 2: Auction Server has IP Address: " << s << " PreAuction Port Number: " << get_port_num(sockfd) << endl;

	freeaddrinfo(servinfo); // all done with this structure

	return sockfd;
}

int main(int argc, char *argv[])
{
	int sockfd, numbytes;
	char buf[MAXDATASIZE];
	int i, j, k;

	//***** Phase 1 *****

	//read registration login information
	char filename[25]; //filename
	char sID[2]; //sellerID as string
	sprintf(sID, "%d", sellerID);
	strcpy(filename, "sellerPass");
	strcat(filename, sID);
	strcat(filename, ".txt");
	//cout << filename <<endl;
	readFile(filename);

	//generate login message
	char loginMsg[50]; //login msg
	strcpy(loginMsg, "Login#");
	for (i=0; i<4; i++) {
		//cout << regArr[i] <<endl;
		if (i<4) {
			strcat(loginMsg, regArr[i].c_str());
			strcat(loginMsg," "); //add extra blank space
		}
		else {strcat(loginMsg, regArr[i].c_str());}
	}
	//cout <<loginMsg<<endl;

	//establish TCP connection to auction server
	sockfd = create_client_seller_TCP();

	//send login info to auction server
	cout << "Phase 1: Login Request. User: " << regArr[1] << " password: " <<
			regArr[2] << " and Bank account: " << regArr[3] << endl;
	if (send(sockfd, loginMsg, strlen(loginMsg), 0) == -1)
				perror("send");

	//receive login info from auction server
	if ((numbytes = recv(sockfd, buf, MAXDATASIZE-1, 0)) == -1) {
		perror("recv");
		exit(1);
	}
	else {
		buf[numbytes] = '\0';
		cout << "Phase 1: Login request reply: " << buf << endl;

		if (strncmp(buf, "Accepted#",9) == 0) {
			//parse preAuction (phase 2) ip address and port number from phase 1 auction server reply message
			istringstream oss(buf);
			string word;
			int cntr;
			while(getline(oss, word, '#')) { //cmd word processing
				if (strcmp(word.c_str(),"Accepted")==0) {
					cntr=0; //reset data ref cntr
					while(oss >> word) {//cmd argument processing
						//cout << "[" << word << "] "<< endl;
						if (cntr==0) {ip_ph2 = word.c_str();} //phase 2 auction server ip address
						else if (cntr==1) {pn_ph2 = word.c_str();} //phase 2 auction server port number
						cntr++; //increase data ref cntr
					}
					cout << "Phase 1: Auction Server has IP Address " << ip_ph2
							<< " and PreAuction TCP Port Number " << pn_ph2 <<endl;
					break;
				}
				else {
					pn_ph2 = "0";
					break;}
			}
		}
	}
	cout << "End of Phase 1 for Seller# " << sellerID << endl;
	close(sockfd);

	if (strcmp(pn_ph2.c_str(), "0")==0) {
//		cout<<"I failed login, boo :("<<endl;
		return 1;
	} //stop the script from moving past Phase 1 if login fails.

	//***** Phase 2 *****
	sleep(1); //take a 1 second pause while phase 2 auction server sets up

	//read in the item list
	string itemlist = "";
	char filename2[25]; //filename
	char sID2[2]; //sellerID as string
	sprintf(sID2, "%d", sellerID);
	strcpy(filename2, "itemList");
	strcat(filename2, sID2);
	strcat(filename2, ".txt");
	ifstream file(filename2);
	string temp;
	while(getline(file, temp)) {
	  itemlist+=temp;
	  itemlist+="\n";
	}
	//cout<<itemlist<<endl;

	//generate itemlist message
	char itemlistMsg[50]; //itemlist msg
	strcpy(itemlistMsg, "ItemList#");
	strcat(itemlistMsg, itemlist.c_str());
//	cout <<itemlistMsg<<endl;

	//establish TCP connection to auction server
	sockfd = create_client_seller_TCP_ph2();

	//send item list
	cout << "Phase 2: Seller# " << sellerID << " send item lists." <<endl;
	cout << "Phase 2: " << itemlist << endl;
	if (send(sockfd, itemlistMsg, strlen(itemlistMsg), 0) == -1)
				perror("send");

	//receive reply from auction server
	if ((numbytes = recv(sockfd, buf, MAXDATASIZE-1, 0)) == -1) {
		perror("recv");
		exit(1);
	}
	else {
		buf[numbytes] = '\0';
//		cout << "Phase 2: Item List reply: " << buf << endl;
	}

	cout << "End of Phase 2 for Seller# " << sellerID << endl;

	cout<<"End of Phase 3 for Seller# " << sellerID << ". (Did not finish project past Phase 2)" << endl;
	//***** NOTE: The seller code ends here as I did not finish the project beyond phase 2. *****


	//***** Phase 3 *****

	return 0;
}

