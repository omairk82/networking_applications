/*
** bidder.c --
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unistd.h>

using namespace std;

int bidderID = 2; //bidder id #
string regArr[4]; //registration info array

//#define PORT "3490" // the port client will be connecting to
#define TCP_PORT_AS1 "1100996"  // Auction Server TCP port for phase 1
#define TCP_PORT_AS2 "1200996" // Auction Server TCP port for phase 2
#define TCP_PORT_S1 "2200996" // Seller 1 Server TCP port for phase 3
#define TCP_PORT_S2 "2100996" // Seller 2 Server TCP port for phase 3
#define TCP_PORT_B1 "4100996" // Bidder 1 Server UDP port for phase 3
#define TCP_PORT_B2 "4200996" // Bidder 2 Server UDP port for phase 3
#define UDP_PORT_B1 "3100996" // Bidder 1 Server UDP port for phase 3
#define UDP_PORT_B2 "3200996" // Bidder 2 Server UDP port for phase 3

#define MAXDATASIZE 100 // max number of bytes we can get at once 

void readFile(char* filenm) {
	ifstream file(filenm);
	string str;
	while (getline(file, str))
	{
		//cout << str <<endl;
		// Process str
		int i =0;
		stringstream ssin(str);
		while (ssin.good() && i < 4){
			ssin >> regArr[i];
			++i;
		}
	}
}

int get_port_num(int sockfd) {
	struct sockaddr_in sin;
	socklen_t len = sizeof(sin);
	if (getsockname(sockfd, (struct sockaddr *)&sin, &len) == -1)
		perror("getsockname");
//	else
//    	printf("port number %d\n", ntohs(sin.sin_port));

	return ntohs(sin.sin_port);
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int create_client_bidder_TCP(){
	int sockfd;
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo("nunki.usc.edu", TCP_PORT_AS1, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and connect to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("bidder: socket");
			continue;
		}

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("bidder: connect");
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "bidder: failed to connect\n");
		return 2;
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
			s, sizeof s);

	//printf("bidder: connecting to %s\n", s);
	cout << "Phase 1: " << "Bidder " << bidderID << " has TCP port " << get_port_num(sockfd) << " and IP address: " << s << endl;

	freeaddrinfo(servinfo); // all done with this structure

	return sockfd;
}

int main(int argc, char *argv[])
{
	int sockfd, numbytes;  
	char buf[MAXDATASIZE];
	int i, j, k;

	//***** Phase 1 *****

	//read registration login information
	char filename[25]; //filename
	char bID[2]; //bidderID as string
	sprintf(bID, "%d", bidderID);
	strcpy(filename, "bidderPass");
	strcat(filename, bID);
	strcat(filename, ".txt");
	//cout << filename <<endl;
	readFile(filename);

	//generate login message
	char loginMsg[50]; //login msg
	strcpy(loginMsg, "Login#");
	for (i=0; i<4; i++) {
		//cout << regArr[i] <<endl;
		if (i<4) {
			strcat(loginMsg, regArr[i].c_str());
			strcat(loginMsg," "); //add extra blank space
		}
		else {strcat(loginMsg, regArr[i].c_str());}
	}
	//cout <<loginMsg<<endl;

	//establish TCP connection to auction server
	sockfd = create_client_bidder_TCP();

	//send login info to auction server
	cout << "Phase 1: Login Request. User: " << regArr[1] << " password: " <<
			regArr[2] << " and Bank account: " << regArr[3] << endl;
	if (send(sockfd, loginMsg, strlen(loginMsg), 0) == -1)
				perror("send");

	//receive login info from auction server
	if ((numbytes = recv(sockfd, buf, MAXDATASIZE-1, 0)) == -1) {
		perror("recv");
		exit(1);
	}
	else {
		buf[numbytes] = '\0';
//		cout << "Phase 1: Login request reply: " << buf << endl;
//		printf("seller: received '%s'\n",buf);
//		if (strncmp(buf, "Accepted#",9) == 0) {
//			cout << "Yay I'm logged in!" << endl;
//		}
//		else {
//			cout << "Boo not logged in! " << endl;
//		}
	}

	close(sockfd);
	cout<<"End of Phase 3 for Bidder. (Did not finish project past Phase 2)"<<endl;

	//***** NOTE: The bidder code ends here as I did not finish the project beyond phase 2. *****

	//***** Phase 2 *****



	//***** Phase 3 *****

	return 0;
}

