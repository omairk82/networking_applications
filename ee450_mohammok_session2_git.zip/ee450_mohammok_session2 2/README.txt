a. Name: Mohammed Omair Khan

c. Summary of work: I did only phases 1 and 2 of the assignment.
The code will run to completion until phase 2 and gracefully exit on its own.
All networking aspects of the code were used from Beej's networking tutorial.
I added my own code to deal with processing the data being sent between auction server, bidder, and seller.

d. Code Details: I did not use any mutli-threaded processes, so I have submitted the following files:
- auctionserver.cpp:
	Sets up a synchronous I/O multiplexing server (per Beej's networking code) that can handle data from multiple clients.
	The main workhorse of this file is CreateMultiSynchIOServer_Phase1() and CreateMultiSynchIOServer_Phase2().
	These files contain not only the networking code, but also the logic to process and reply to message from clients.
	Seller and Client data are stored into structs for use in phases 1 and 2.
- bidder1.cpp and bidder2.cpp:
	Sets up a simple socket connection, and talks and receives over that socket for phases 1 and 2.
	Each talk and receive command is done in serial according the flow of operations in the project description.
	Phase 1 commands are sent in the format of "Login#<Type> <Name> <Password> <BankAcct>"
- seller1.cpp and seller1.cpp
	Sets up a simple socket connection, and talks and receives over that socket for phases 1 and 2.
	Each talk and receive command is done in serial according the flow of operations in the project description.
	Phase 1 commands are sent in the format of "Login#<Type> <Name> <Password> <BankAcct>"
	Phase 1 response messages for received item lists are in the format of "Accepted#<Phase 2 IP address> <Phase 2 port number>"
	Phase 2 commands set with with "ItemList#<Name> <Item \n;{repeats}>"
	Phase 2 response messages for received item lists are "Accepted#" - there are not argument for this reponse message in phase 2.
- MakeFile
	runs all the g++ compile commands for the .cpp files
- runProj
	execute the c++ executable files in the proper order
The last two files (MakeFile and runProj) are shell scripts that will compile and run the program for the user. I hope these are eligible for extra credit :-)
The scripts will shut themselves down.

e. How to run the program:
To run the project, enter the following at the command line from the project directory:
./MakeFile; ./runProj
The program runs in one terminal window, e.g. all on screen messages are sent to the same term window.
Once the user sees the following return statement, the scripts have all ended:
"End of Phase 3 for Auction Server (Did not finish project past Phase 2)"
Upon completion of behavior, the scripts will shut themselves down.

f. Format of messages:
All on-screen messages are of the same format as mentioned in the project description.
If errors come up for the networking aspect of code, errors are returned using perror() - using the same struture as Beej's networking tutorial.
See Summary of Work above for message format for commands sent between clients.

g. Idiosyncrasies:
The code will NOT work correctly under the following conditions:
- The code only runs behaviors associated with phase 1 and phase 2. Phase 3 is not implemented.
- Requires 2 bidder and 2 sellers to attempt logins during Phase 1
- Format of bidder and seller data files must follow format specified in the project description.
- All data files must not contain any '#' characters, as this is specially set aside as a command indicator/delimiter.
- Usernames among bidders and sellers must be unique.
- If both sellers fail login, the program will work fine, but the server will immediately exit phase 2 (as is expected).
- On some random occasions, the user may see a 'failed to bind' error message from the auction server, but this is reset, so it is not an issue.
	I left the error message in just to be aware of the situation and make sure there isn't a larger issues occurring. These messages rarely show up.

h. Reused Code:
- auctionserver.cpp makes heavy use of selectserver.c from Beej's networking examples (http://beej.us/guide/bgnet/examples/)
My own code is only used for handling data that is sent between the scripts (e.g. parsing string, storing data for future use, etc) 
- bidder1/2.cpp and seller1/2.cpp makes modified use of sections of client.c and server.c from Beej's networking examples (http://beej.us/guide/bgnet/examples/)
My own code is only used for handling data that is sent between the scripts (e.g. parsing string, storing data for future use, etc) 
